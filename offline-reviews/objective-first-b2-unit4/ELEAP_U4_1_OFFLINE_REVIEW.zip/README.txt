E-LEAP OBJECTIVE FIRST B2 UNIT 4 OFFLINE REVIEW
Open index.html in Chrome / Edge. Works without internet.
TEACHER REVIEW ONLY. No Production data, no actual QR/Responses.
Reading A-E are original supplementary practice texts, NOT verbatim Cambridge textbook reading.
The textbook questions remain to be completed with the student's book.
No source media is bundled. This review focuses on Bloom aims, teaching sequence, scrolling Reading, Check / Reveal / Evidence / Why.

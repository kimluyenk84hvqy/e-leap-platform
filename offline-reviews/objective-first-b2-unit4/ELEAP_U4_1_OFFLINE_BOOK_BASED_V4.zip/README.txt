E-LEAP OBJECTIVE FIRST B2 – UNIT 4.1 ENDANGERED
OFFLINE CLASSROOM REVIEW
Extract the whole ZIP. Open index.html in Chrome or Edge. No internet required.
Built from the uploaded 31-slide Unit 4.1 PPT and the supplied Cambridge Objective First B2 textbook pages 28–29. Includes six real wildlife photos (Wikimedia Commons), five source reading passages, ten original multiple-matching questions, Book Exercises 1–6, reading group share, vocabulary and speaking.
Source mismatch to inspect: the provided PPT uses 'converse / conversation' where reading C visibly says 'conservation'. The auto-checked activity follows the verified text C: conserve → conservation.
Photo credits: Wikimedia Commons photos titled 'Polar bear silently stepping from an ice floe', 'Rhynchopsitta-pachyrhyncha', 'Tiger Shark Galeocerdo Cuvier (223179837)', 'Snow Leopard on Snowy Rocks (23966719139)', 'Koala 2026', and 'Orangutan and infant Sumatra'. Check original photo license and attribution before publishing publicly.
Background references: https://www.worldwildlife.org/species/polar-bear/ ; https://www.worldwildlife.org/species/snow-leopard/ ; https://www.floridamuseum.ufl.edu/discover-fish/species-profiles/tiger-shark/ .
Teacher review package; does not include recording of original warm-up video or actual E-LEAP Live Class/Response data. Do not republish book text publicly.

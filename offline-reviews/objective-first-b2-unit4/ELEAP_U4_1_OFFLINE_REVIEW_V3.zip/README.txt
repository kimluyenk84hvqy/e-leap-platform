E-LEAP U4.1 OFFLINE REVIEW V3
Open index.html after extracting all contents. Includes 3 real wildlife photos, 12 slides, one Reading slide with Read, Share, Answer and Discuss buttons, continuous A-E scroll, independent right scroll, Check, Evidence, WHY and Key by item.
These five Reading texts are SUPPLEMENTARY ORIGINAL practice and not the Cambridge Student's Book reading. The original textbook matching task must be done using Student's Book.
Images via Wikimedia Commons CC BY-SA 4.0: Polar bear silently stepping from an ice floe (Andreas Weith); Tiger walking through grass (Davidvraju); Orangutan and infant Sumatra (Anton Leddin). Source links: https://commons.wikimedia.org.
No videos or student database in this Offline teacher review. NOT a Production-approved Final.

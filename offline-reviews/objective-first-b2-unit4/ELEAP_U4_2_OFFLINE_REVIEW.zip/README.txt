E-LEAP OBJECTIVE FIRST B2 UNIT 4 OFFLINE REVIEW
Extract the ZIP. Open index.html in Chrome or Edge; no internet required.
PREVIEW / REVIEW only. This is not an approved FINAL or E-LEAP Production release.
U4.1 contains newly written supplementary Reading A-E, NOT the original Cambridge passage; use the book for textbook tasks.
Media clips are NOT bundled pending verified source edits. Teacher preview is local with Check, Reset, Show Answer, Evidence and WHY.

E-LEAP OBJECTIVE FIRST B2 UNIT 4 OFFLINE REVIEW
Extract ZIP, open index.html in Chrome/Edge. No internet required.
TEACHER REVIEW ONLY: not for final assessment or production publication.
U4.1 Reading A-E are newly written supplementary jigsaw texts, not verbatim Cambridge textbook content.
The exact Student's Book questions should be checked against the physical book.
Videos/audio NOT bundled pending source verification. Offline demo provides Check, Reset, Show Answer, WHY, item Evidence, timer and independent scroll in Reading.

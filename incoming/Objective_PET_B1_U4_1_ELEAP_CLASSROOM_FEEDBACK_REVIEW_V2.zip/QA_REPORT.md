# U4.1 CLASSROOM FEEDBACK PASS — QA REPORT

- Version: `1.5.0-u41-classroom-feedback-pass`
- Screens: **19**
- Referenced local assets: **49**; missing: **0**
- New audio clips: **34**; invalid/too short: **0**
- Visible instruction metadata violations (INDIVIDUAL/PAIR/MIN in learner instruction): **0**

## Feedback-to-fix checks
- PASS — item_scoped_reveal
- PASS — evidence_highlight
- PASS — vertical_page_scroll
- PASS — reading_inner_scroll
- PASS — fixed_navigation
- PASS — light_teacher_toolbar
- PASS — brighter_media
- PASS — aims_slide
- PASS — intro_integrated
- PASS — reading_jigsaw
- PASS — pron_item_audio
- PASS — hand_raise_game

## Source-safe decisions
- Track 15 is split into six replay buttons, but no official key is fabricated.
- Reading A–F text and Reading/Vocabulary answers are grounded in the supplied U4.1 PPT.
- Track 16 is split into three conversations; evidence replay/transcript is provided for gist feedback.
- Pronunciation Days uses Track 17; Months/Dates clips are cut from supplied Track 18.

## Interaction redesign
- Introduction 3–4 integrated: Describe/Guess → personal preference/justification.
- Reading 2: A reads A+B, B reads C+D, C reads E+F → group oral report → six group answers → evidence verification.
- Reading/Vocabulary: 50/50 scrollable source pane + question/answer pane; teacher Evidence highlights source phrase.
- Time Expressions: four teams ON / AT / IN / —; 18 mixed phrases, one at a time.

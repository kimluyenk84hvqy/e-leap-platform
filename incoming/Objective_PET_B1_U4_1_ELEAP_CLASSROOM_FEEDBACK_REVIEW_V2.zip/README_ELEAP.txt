E-LEAP Resource Review V2 — Objective PET B1 U4.1
Copy/merge resources/objective-pet-b1/u04/l01/ into the existing E-LEAP repository.
Do not duplicate Platform Core teacher controls in hosted mode.
Show Answer command now toggles answer mode; while active, clicking an item reveals only that item.
Evidence remains item-scoped inside the lesson canvas.
Track 15 is gradable using the reveal mapping recovered from the supplied PPT.
Reading 2 uses three local visual states but remains one pedagogical activity and one activityId.

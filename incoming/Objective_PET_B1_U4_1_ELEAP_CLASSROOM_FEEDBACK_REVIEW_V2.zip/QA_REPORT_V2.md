# U4.1 Classroom Feedback Review V2 — QA Report

Version: 1.6.0-u41-feedback-v2-answer-mode-reading2

## Implemented feedback
- Show Answer simplified to one global mode: click Show Answer once, then click any item to reveal only that item's answer.
- Per-item Answer buttons removed; Evidence stays item-scoped.
- Answer overlays the response box, so Evidence remains visible.
- Track 15 uses full audio first. Source-derived answer map recovered from the supplied PPT reveal labels: A–1, B–4, C–6, D–3, E–5, F–2.
- Track 15 Evidence opens the matching short audio clip under the correct picture.
- Reading 2 rebuilt into 3 tabs: (1) six members / six texts / oral summary; (2) questions only; (3) split-screen Check & Evidence.
- Reading 2 question panes use independent vertical scroll and enlarged question typography.

## Static QA
- 19 screens / 11 activities.
- JS syntax: PASS for Offline and E-LEAP mirrors.
- Missing referenced assets: 0.
- Offline / E-LEAP app.js: mirrored.
- Offline / E-LEAP styles.css: mirrored.
- Offline / E-LEAP lesson-data.js: mirrored.
- Per-item data-teacher-answer controls: 0.
- Old Reading 2 title 'Read · Tell · Answer · Verify': removed.
- Track 15 now gradable/checkable with source-derived key.

## Interaction contract
- Offline Teacher toolbar: Show Answer toggles answer mode.
- Hosted mode: Platform Core Show Answer command toggles the same lesson answer mode; no duplicate lesson toolbar is introduced.
- Reading 2 remains one pedagogical activity / one activityId across all three tabs.
- Evidence does not create a new assessment or score.

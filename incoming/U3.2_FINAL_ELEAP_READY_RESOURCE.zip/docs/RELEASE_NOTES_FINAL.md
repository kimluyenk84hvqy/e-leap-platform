# U3.2 FINAL — CONTENT / VISUAL / IN-LESSON FUNCTION LOCK

Date: 12 Oct 2026

## Final audit
- Rechecked Objective PET coursebook pp.25–27 and lecturer PPT.
- Verified Short Answers, Pronunciation, Spot the Difference, What’s my job?, Speaking Part 3 Exercises 1–4, and Reading Part 5 Exercises 1–2.
- Confirmed that Reading Part 5 has no separate reading passage: the photographs are the context, followed by three gap-fill multiple-choice items in each exercise.
- Restored exact source task instructions above Speaking Ex.4 and Reading Part 5 Ex.1/Ex.2.
- Preserved the fresh lime Objective PET identity, enlarged projector typography, Exam Folder divider, image-supported tabs, and final Thank You screen.
- No unsupported source text was invented.

## Scope note
This FINAL package locks lesson content, visual design, and standalone/in-lesson interaction. Platform-level QR, Live Class, Responses and two-device synchronization remain governed and QA’d by the shared E-LEAP platform contract.

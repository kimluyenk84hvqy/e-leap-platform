(function(){
  const api = {};
  const hosted = window.self !== window.top || new URLSearchParams(location.search).get('eleapHosted') === '1';
  window.__ELEAP_HOSTED__ = hosted;
  function app(){ return window.ELEAPApp; }
  api.setMode = mode => app()?.setMode(mode);
  api.getMode = () => app()?.getMode() || 'student';
  api.getActivityState = () => app()?.getActivityState() || null;
  api.command = (action,payload) => app()?.command(action,payload);
  api.setScreen = target => app()?.setScreen(target);
  api.setActivity = activityId => app()?.setActivity(activityId);
  window.ELEAPLesson = api;
  window.addEventListener('message', e=>{
    const d=e.data||{};
    if(d.type==='ELEAP_COMMAND' && d.action) api.command(d.action,d.payload);
    if(d.type==='ELEAP_SET_MODE') api.setMode(d.mode);
    if(d.type==='ELEAP_SET_SCREEN') api.setScreen(d.target);
    if(d.type==='ELEAP_SET_ACTIVITY') api.setActivity(d.activityId);
  });
  window.addEventListener('ELEAP_APP_READY',()=>{
    try{ window.parent?.postMessage({type:'ELEAP_LESSON_READY',resourceId:window.LESSON?.resourceId},'*'); }catch(e){}
  });
})();

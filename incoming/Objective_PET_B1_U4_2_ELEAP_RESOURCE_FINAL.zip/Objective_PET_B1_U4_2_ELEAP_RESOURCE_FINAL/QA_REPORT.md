# U4.2 E-LEAP RESOURCE — INTEGRATION QA

**Resource:** `res-objective-pet-b1-u04-l02`  
**Course:** Objective PET B1  
**Unit/Lesson:** U4.2  
**Source content:** OFFLINE FINAL V8

## Packaging checks
- [x] Lesson content separated from Platform Core.
- [x] E-LEAP resource entrypoint contains no standalone Check/Reset/Submit/Show Answer toolbar.
- [x] Hosted bridge retained: `ELEAP_LESSON_READY`, `ELEAP_LESSON_STATE`, `ELEAP_COMMAND`.
- [x] `getActivityState()`, `setScreen()`, `setActivity()`, `command()` retained.
- [x] Stable resource ID: `res-objective-pet-b1-u04-l02`.
- [x] Local relative media assets retained; no media converted to base64.
- [x] Activity definitions and answer keys retained in `lesson.json`.
- [x] Resource manifest included.

## Status
**E-LEAP RESOURCE PACKAGE READY FOR STAGING/QA.**  
Not yet labelled Production Ready: two-device Teacher + TEST001 Live Class / Submit / Responses / Follow Teacher QA is still required on the real E-LEAP platform.
